/*
 * Davis Odom
 * 9/8/15
 * A class that does the same thing as ArrayList
 */
import java.util.ArrayList;

public class MyStack extends ArrayList<Object>{
	
}
